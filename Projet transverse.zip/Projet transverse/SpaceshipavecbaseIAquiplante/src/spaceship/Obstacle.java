/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package spaceship;

/**
 *
 * @author 20160345
 */
public class Obstacle extends Object_ {
    
    public Obstacle (int x, int y)
    {
        super(x, y);
    }
}
