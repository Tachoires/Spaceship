/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package spaceship;
import java.util.*;


public class Object_ {
    private int x, y;
    private ArrayList<Missile> missiles;
    
    public Object_(int x, int y){
        this.x = x;
        this.y = y;
        missiles = new ArrayList();
    }
    
    public int getX(){
        return x;
    }

    public int getY(){
        return y;
    }
    
    public ArrayList<Missile> getMissile(){
        return new ArrayList<Missile>(missiles);
    }

        //Mouvements
    public boolean setLeft(){
        if(x != 0)
        {
            this.x--;
        }
            
        else
            System.out.println("Houston on a un problema");
                    
        return (x+1) != 0;

    }
    
    public boolean setRight(){
        if(x != 11)
            this.x++;
        return (x-1) != 11;
    }
    
    public boolean setUp(){
        if (y != 0)
            this.y--;
        return (y+1) != 0;
    }

    public boolean setDown(){
        if (y != 11)
            this.y++;
        return (y-1) != 11;
    }
    
    public boolean move(char direction){
        switch(direction)
        {
            case 'q':     //Left
                return setLeft();
            case 'd':     //Right
                return setRight();
            case 'z':     //Up
                return setUp();
            case 's':     //Down
                return setDown();
            default:
                System.out.println("(Fatal)Error!");
                return false;
        }
    }
    
    //Missiles
    
    public void addMissile(int x, int y, int type, int direction)
    {
        missiles.add(new Missile(x, y, type, direction));
    }
    
     public void delMissile(Missile missile)
    {
        missiles.remove(missile);
    }
    
    public boolean tir(int x, int y, char type_tir, int joueur)
    {
        if (joueur == 1)
        {
            switch(type_tir)
            {
            case '1':     //Left
                this.addMissile(x, y - 1, 1 + 4, 1);
                return true;
            case '2':     //Right
                this.addMissile(x, y - 1, 2 + 4, 2);
                return true;
            default:
                System.out.println("(Fatal)Error!");
                return false;
            }
        }
        else { //joueur == 2
            switch(type_tir)
            {
            case '1':     //Left
                this.addMissile(x, y + 1, 1 + 4, 1);
                return true;
            case '2':     //Right
                this.addMissile(x, y + 1, 2 + 4, 2);
                return true;
            default:
                System.out.println("(Fatal)Error!");
                return false;
            }
        }
        
    }
}
